import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBody,
  ApiCreatedResponse,
  ApiNoContentResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import {
  ApiAuthenticated,
  ApiForbidden,
} from '../../../shared/http/decorators/api-auth-responses.decorator.js';
import {
  ApiIdParam,
  ApiNotFound,
} from '../../../shared/http/decorators/api-resource-responses.decorator.js';
import { IdParam } from '../../../shared/http/decorators/id-param.decorator.js';
import { ApiPaginatedResponse } from '../../../shared/http/decorators/api-paginated-response.decorator.js';
import { ValidationErrorResponseDto } from '../../../shared/http/dto/error-response.dto.js';
import { PaginationQueryDto } from '../../../shared/http/dto/pagination-query.dto.js';
import type { AuthenticatedUser } from '../../auth/domain/authenticated-user.entity.js';
import { CurrentUser } from '../../auth/presentation/decorators/current-user.decorator.js';
import { JwtAuthGuard } from '../../auth/presentation/guards/jwt-auth.guard.js';
import { CreateTripActivityDto } from '../application/dto/create-trip-activity.dto.js';
import { UpdateTripActivityDto } from '../application/dto/update-trip-activity.dto.js';
import { TripActivityResponseDto } from '../application/dto/trip-activity-response.dto.js';
import { TripActivitiesService } from '../application/trip-activities.service.js';

@ApiTags('Trip Activities')
@UseGuards(JwtAuthGuard)
@Controller('trip-activities')
export class TripActivitiesController {
  constructor(private readonly service: TripActivitiesService) {}

  @ApiOperation({
    summary: 'List planned activities',
    description:
      'Returns the activities planned for a trip in chronological order. Entries without a date come last.',
  })
  @ApiPaginatedResponse(
    TripActivityResponseDto,
    'Page of planned activity records.',
  )
  @ApiUnprocessableEntityResponse({
    description: 'Invalid pagination parameters.',
    type: ValidationErrorResponseDto,
  })
  @ApiAuthenticated()
  @Get()
  findAll(
    @Query() query: PaginationQueryDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.service.findAll(query, user);
  }

  @ApiOperation({
    summary: 'Get a planned activity by id',
    description:
      'Returns one scheduled activity with its time, duration and expected cost.',
  })
  @ApiIdParam('TripActivity identifier.')
  @ApiOkResponse({
    description: 'The requested planned activity.',
    type: TripActivityResponseDto,
  })
  @ApiNotFound('No planned activity exists with this id.')
  @ApiAuthenticated()
  @Get(':id')
  findOne(@IdParam() id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.service.findOne(id, user);
  }

  @ApiOperation({
    summary: 'Plan an activity',
    description:
      'Schedules a catalog activity inside one stop of the itinerary. Requires EDITOR permission on the trip.',
  })
  @ApiBody({ type: CreateTripActivityDto })
  @ApiCreatedResponse({
    description: 'The created planned activity.',
    type: TripActivityResponseDto,
  })
  @ApiUnprocessableEntityResponse({
    description: 'The payload failed validation.',
    type: ValidationErrorResponseDto,
  })
  @ApiForbidden('The caller has read-only (VIEWER) access to the trip.')
  @ApiAuthenticated()
  @Post()
  @HttpCode(HttpStatus.CREATED)
  create(
    @Body() dto: CreateTripActivityDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.service.create(dto, user);
  }

  @ApiOperation({
    summary: 'Update a planned activity',
    description:
      'Adjusts schedule, duration, cost or status. The stop and the catalog entry cannot be reassigned.',
  })
  @ApiIdParam('TripActivity identifier.')
  @ApiBody({ type: UpdateTripActivityDto })
  @ApiOkResponse({
    description: 'The updated planned activity.',
    type: TripActivityResponseDto,
  })
  @ApiNotFound('No planned activity exists with this id.')
  @ApiUnprocessableEntityResponse({
    description: 'The payload failed validation.',
    type: ValidationErrorResponseDto,
  })
  @ApiForbidden('The caller has read-only (VIEWER) access to the trip.')
  @ApiAuthenticated()
  @Patch(':id')
  update(
    @IdParam() id: string,
    @Body() dto: UpdateTripActivityDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.service.update(id, dto, user);
  }

  @ApiOperation({
    summary: 'Remove a planned activity',
    description:
      'Removes the activity from the itinerary. The catalog entry is untouched.',
  })
  @ApiIdParam('TripActivity identifier.')
  @ApiNoContentResponse({ description: 'Deleted. No content returned.' })
  @ApiNotFound('No planned activity exists with this id.')
  @ApiForbidden('The caller has read-only (VIEWER) access to the trip.')
  @ApiAuthenticated()
  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@IdParam() id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.service.remove(id, user);
  }
}
