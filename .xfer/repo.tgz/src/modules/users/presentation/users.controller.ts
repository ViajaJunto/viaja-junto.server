import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Patch,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBody,
  ApiNoContentResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import {
  ApiAuthenticated,
  ApiForbidden,
} from '../../../shared/http/decorators/api-auth-responses.decorator.js';
import {
  ApiIdParam,
  ApiNotFound,
} from '../../../shared/http/decorators/api-resource-responses.decorator.js';
import { IdParam } from '../../../shared/http/decorators/id-param.decorator.js';
import { ApiPaginatedResponse } from '../../../shared/http/decorators/api-paginated-response.decorator.js';
import { ValidationErrorResponseDto } from '../../../shared/http/dto/error-response.dto.js';
import { PaginationQueryDto } from '../../../shared/http/dto/pagination-query.dto.js';
import type { AuthenticatedUser } from '../../auth/domain/authenticated-user.entity.js';
import { CurrentUser } from '../../auth/presentation/decorators/current-user.decorator.js';
import { JwtAuthGuard } from '../../auth/presentation/guards/jwt-auth.guard.js';
import { UpdateUserDto } from '../application/dto/update-user.dto.js';
import { UserResponseDto } from '../application/dto/user-response.dto.js';
import { UsersService } from '../application/users.service.js';

@ApiTags('Users')
@UseGuards(JwtAuthGuard)
@Controller('users')
export class UsersController {
  constructor(private readonly service: UsersService) {}

  @ApiOperation({
    summary: 'List users',
    description:
      'Returns a paginated list of registered users. Requires authentication.',
  })
  @ApiPaginatedResponse(UserResponseDto, 'Page of user records.')
  @ApiUnprocessableEntityResponse({
    description: 'Invalid pagination parameters.',
    type: ValidationErrorResponseDto,
  })
  @ApiAuthenticated()
  @Get()
  findAll(@Query() query: PaginationQueryDto) {
    return this.service.findAll(query);
  }

  @ApiOperation({
    summary: 'Get a user by id',
    description: 'Returns a single user. Requires authentication.',
  })
  @ApiIdParam('User identifier.')
  @ApiOkResponse({ description: 'The requested user.', type: UserResponseDto })
  @ApiNotFound('No user exists with this id.')
  @ApiAuthenticated()
  @Get(':id')
  findOne(@IdParam() id: string) {
    return this.service.findOne(id);
  }

  @ApiOperation({
    summary: 'Update a user',
    description:
      'Updates the authenticated user profile. Accounts are created by signing in with Google, so there is no password to change.',
  })
  @ApiIdParam('User identifier.')
  @ApiBody({ type: UpdateUserDto })
  @ApiOkResponse({ description: 'The updated user.', type: UserResponseDto })
  @ApiNotFound('No user exists with this id.')
  @ApiUnprocessableEntityResponse({
    description: 'The payload failed validation.',
    type: ValidationErrorResponseDto,
  })
  @ApiForbidden('The token belongs to a different user.')
  @ApiAuthenticated()
  @Patch(':id')
  update(
    @IdParam() id: string,
    @Body() dto: UpdateUserDto,
    @CurrentUser() caller: AuthenticatedUser,
  ) {
    return this.service.update(id, dto, caller);
  }

  @ApiOperation({
    summary: 'Delete a user',
    description:
      'Permanently deletes the account and every trip membership and review attached to it.',
  })
  @ApiIdParam('User identifier.')
  @ApiNoContentResponse({ description: 'Deleted. No content returned.' })
  @ApiNotFound('No user exists with this id.')
  @ApiForbidden('The token belongs to a different user.')
  @ApiAuthenticated()
  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@IdParam() id: string, @CurrentUser() caller: AuthenticatedUser) {
    return this.service.remove(id, caller);
  }
}
